package com.carlauncher.player

import kotlin.math.max
import kotlin.math.min

/**
 * شبیه‌ساز دور موتور برای گیربکس CVT با ۷ دنده‌ی مجازی.
 * ورودی: سرعت (km/h). خروجی: دور موتور (rpm) و دنده‌ی مجازی.
 * شتاب از روی تغییر سرعت تخمین زده می‌شود (گاز تقریبی) و بر اساس آن:
 *  - نقطه‌ی تعویض دنده بالا می‌رود (شتاب شدید = دور بالاتر)
 *  - زیر شتاب شدید، CVT دور موتور را کمی جلوتر از سرعت می‌برد (حس CVT)
 *  - در تعویض دنده‌ی مجازی، دور لحظه‌ای افت یا جهش می‌کند
 */
class CvtSim {
    // دور موتور به ازای هر km/h در هر دنده‌ی مجازی (دنده ۱ تا ۷)
    private val k = floatArrayOf(118f, 74f, 52f, 39f, 30f, 24f, 20f)

    var mode = 0            // 0 نرمال، 1 اسپرت، 2 برفی، 3 کم‌مصرف
    var gear = 1
        private set
    var rpm = 800f
        private set
    var throttle = 0f
        private set

    private var lastSpeed = 0f
    private var accelF = 0f
    private var shiftT = 0f
    private val idle = 780f

    fun update(speed: Float, dt: Float): Float {
        val a = (speed - lastSpeed) / max(0.01f, dt)
        lastSpeed = speed
        accelF += (a - accelF) * min(1f, dt * 2.5f)
        val demand = (accelF / 7f).coerceIn(-1f, 1f)
        val cruise = if (speed > 5f) 0.10f else 0f
        throttle = max(cruise, demand)

        val up: Float
        val down: Float
        val boost: Float
        when (mode) {
            1 -> { up = 3800f + 3000f * throttle; down = 2300f + 1500f * throttle; boost = 900f }
            2 -> { up = 1800f + 1200f * throttle; down = 1100f + 500f * throttle; boost = 250f }
            3 -> { up = 1900f + 1600f * throttle; down = 1100f + 500f * throttle; boost = 200f }
            else -> { up = 2300f + 2700f * throttle; down = 1300f + 1000f * throttle; boost = 550f }
        }

        if (speed < 2f) {
            gear = 1
        } else if (shiftT <= 0f) {
            val r = speed * k[gear - 1]
            if (r > up && gear < 7) {
                gear++
                shiftT = 0.40f
            } else if (gear > 1 && r < down) {
                gear--
                shiftT = 0.30f
            } else if (throttle > 0.8f && gear > 2 && r < up * 0.62f) {
                gear--
                shiftT = 0.30f
            }
            if (mode == 2 && speed > 3f && gear < 2) gear = 2
        }

        var target = speed * k[gear - 1] + max(0f, throttle) * boost
        if (speed < 3f) target = idle + max(0f, throttle) * 600f
        if (shiftT > 0f) {
            shiftT -= dt
            target -= 250f
        }
        val rate = if (shiftT > 0f) 9f else 6f
        rpm += (target - rpm) * min(1f, dt * rate)
        val limit = if (mode == 1) 7300f else 6800f
        rpm = rpm.coerceIn(idle * 0.95f, limit)
        return rpm
    }
}
