package com.carlauncher.player

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import org.osmdroid.views.overlay.TilesOverlay
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.roundToInt

class DashboardActivity : Activity() {

    private class Tile(val box: LinearLayout, val icon: ImageView, val title: TextView, val value: TextView) {
        var on = false
    }

    private lateinit var prefs: Prefs
    private lateinit var music: MusicController
    private lateinit var radios: Radios
    private val sim = CvtSim()
    private val handler = Handler(Looper.getMainLooper())
    private var builtVersion = -1

    // ---- تم ----
    private var th: Th = Themes.NORMAL
    private var modeIdx = 0
    private var themeAnim: ValueAnimator? = null
    private val tPrimary = ArrayList<TextView>()
    private val tSub = ArrayList<TextView>()
    private val tAccent = ArrayList<TextView>()
    private val iPrimary = ArrayList<ImageView>()
    private val cardViews = ArrayList<View>()
    private val cardRadius = ArrayList<Int>()
    private val cardAlpha = ArrayList<Int>()
    private val tiles = ArrayList<Tile>()

    // ---- views ----
    private lateinit var root: FrameLayout
    private lateinit var header: HeaderView
    private lateinit var dial: DialView
    private lateinit var mapView: MapView
    private lateinit var mask: CornerMask
    private lateinit var sport: SportOverlay
    private lateinit var navBtn: ImageButton
    private lateinit var statusDots: DotsView
    private lateinit var netTv: TextView
    private lateinit var wifiIcon: ImageView
    private lateinit var gpsIcon: ImageView
    private lateinit var cloudIcon: ImageView
    private lateinit var tempTv: TextView
    private lateinit var clockTv: TextView
    private lateinit var dateTv: TextView
    private lateinit var wifiTile: Tile
    private lateinit var btTile: Tile
    private lateinit var cabinTile: Tile
    private lateinit var gpsTile: Tile
    private lateinit var instrCard: LinearLayout
    private lateinit var instrArrow: ImageView
    private lateinit var instrDist: TextView
    private lateinit var instrText: TextView
    private lateinit var recenterBtn: ImageButton
    private lateinit var pill: LinearLayout
    private lateinit var pillIcon: ImageView
    private lateinit var pillText: TextView
    private lateinit var pillClose: ImageView
    private lateinit var artView: CoverView
    private lateinit var musicTitle: TextView
    private lateinit var musicArtist: TextView
    private lateinit var musicProgress: ProgressLine
    private lateinit var posTv: TextView
    private lateinit var durTv: TextView
    private lateinit var btnPlay: ImageButton
    private lateinit var attrTv: TextView

    // ---- نقشه و مسیر ----
    private lateinit var routeLine: Polyline
    private lateinit var carMarker: Marker
    private lateinit var destMarker: Marker
    private var destOnMap = false
    private var route: Route? = null
    private var tracker: RouteTracker? = null
    private var dest: Dest? = null
    private var follow = true
    private var firstFix = false
    private var orient = 0f
    private var lastReroute = 0L
    private var locationManager: LocationManager? = null
    private var lastLoc: Location? = null
    private var lastLocAt = 0L
    private var curKmh = 0f
    private var weatherAt = 0L
    private var askedPerms = false
    private var downX = 0f
    private var downY = 0f
    private var longRun: Runnable? = null
    private var artKey = ""

    // ---- شبیه‌ساز دور موتور ----
    private var lastSimT = 0L
    private var spdSm = 0f
    private var demoPhase = 0
    private var demoT = 0f
    private var demoV = 0f
    private var sportT = 0f
    private var sportTarget = -1f
    private var sportAnim: ValueAnimator? = null

    // ---- دما ----
    private var cabinTemp: Float? = null
    private var cabinFromSensor = false
    private var sensorMgr: SensorManager? = null
    private var tempSensor: Sensor? = null
    private var lastBatteryRead = 0L

    private val locListener = object : LocationListener {
        override fun onLocationChanged(l: Location) { handleLocation(l) }
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    private val sensorListener = object : SensorEventListener {
        override fun onSensorChanged(e: SensorEvent) {
            if (e.values.isNotEmpty()) cabinTemp = e.values[0]
        }
        override fun onAccuracyChanged(s: Sensor, a: Int) {}
    }

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 450)
        }
    }

    private val simLoop = object : Runnable {
        override fun run() {
            simStep()
            handler.postDelayed(this, 50)
        }
    }

    // =====================================================================
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = Prefs.get(this)
        radios = Radios(this)
        sensorMgr = getSystemService(SENSOR_SERVICE) as SensorManager
        tempSensor = try { sensorMgr?.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE) } catch (e: Exception) { null }
        initOsmdroid()
        music = MusicController(this) { runOnUiThread { updateMusic() } }
        modeIdx = prefs.driveMode.coerceIn(0, 3)
        th = Themes.ALL[modeIdx]
        buildUi()
        applyPrefs()
        music.start()
        requestPerms()
    }

    override fun onResume() {
        super.onResume()
        mapView.onResume()
        if (prefs.version != builtVersion) applyPrefs()
        music.ext.start()
        music.loadIfPermitted()
        startLocation()
        val ts = tempSensor
        if (ts != null) {
            try { sensorMgr?.registerListener(sensorListener, ts, SensorManager.SENSOR_DELAY_NORMAL) } catch (_: Exception) {}
        }
        lastSimT = SystemClock.uptimeMillis()
        handler.post(ticker)
        handler.post(simLoop)
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(simLoop)
        music.svc?.saveState()
        stopLocation()
        try { sensorMgr?.unregisterListener(sensorListener) } catch (_: Exception) {}
        mapView.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        music.stop()
        mapView.onDetach()
        super.onDestroy()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() { /* داشبورد بسته نمی‌شود */ }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_MEDIA_NEXT -> { music.next(); return true }
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> { music.prev(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK -> { music.toggle(); return true }
            KeyEvent.KEYCODE_MEDIA_PLAY -> { if (!music.playing) music.toggle(); return true }
            KeyEvent.KEYCODE_MEDIA_PAUSE -> { if (music.playing) music.toggle(); return true }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    // =====================================================================
    // کمک‌ها برای ثبت ویوها در سیستم تم
    private fun txt(sizeU: Float, role: Int): TextView {
        val t = label(sizeU, th.text)
        when (role) {
            0 -> tPrimary.add(t)
            1 -> tSub.add(t)
            else -> tAccent.add(t)
        }
        return t
    }

    private fun icon(res: Int): ImageView {
        val i = ImageView(this)
        i.setImageResource(res)
        iPrimary.add(i)
        return i
    }

    private fun card(v: View, rU: Int, alpha: Int): View {
        cardViews.add(v)
        cardRadius.add(rU)
        cardAlpha.add(alpha)
        return v
    }

    private fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)

    private fun sideButton(res: Int): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.setPadding(u(11), u(11), u(11), u(11))
        b.background = null
        return b
    }

    // =====================================================================
    // ساخت رابط
    private fun initOsmdroid() {
        val cfg = Configuration.getInstance()
        cfg.load(applicationContext, android.preference.PreferenceManager.getDefaultSharedPreferences(applicationContext))
        cfg.userAgentValue = packageName
        cfg.osmdroidBasePath = File(cacheDir, "osmdroid")
        cfg.osmdroidTileCache = File(cacheDir, "osmdroid/tiles")
    }

    private fun makeTile(iconRes: Int, titleText: String): Tile {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.setPadding(u(11), u(8), u(8), u(8))
        box.isClickable = true
        box.isFocusable = true
        card(box, 16, 255)
        val ic = ImageView(this)
        ic.setImageResource(iconRes)
        box.addView(ic, lp(u(26), u(26)))
        val t = txt(11f, 1)
        t.setFa(titleText)
        t.setSingleLine(true)
        val v = txt(15f, 0)
        v.setSingleLine(true)
        v.ellipsize = TextUtils.TruncateAt.END
        box.addView(t, lp(MATCH, WRAP).also { it.topMargin = u(6) })
        box.addView(v, lp(MATCH, WRAP))
        val tile = Tile(box, ic, t, v)
        tiles.add(tile)
        return tile
    }

    private fun setTile(t: Tile, on: Boolean, value: String) {
        t.on = on
        t.icon.setColorFilter(if (on) th.c1 else th.sub)
        t.value.setFa(value, true)
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.layoutDirection = View.LAYOUT_DIRECTION_LTR
        root.setBackgroundColor(th.bg)

        val shell = LinearLayout(this)
        shell.orientation = LinearLayout.VERTICAL
        shell.setPadding(u(12), u(2), u(12), u(12))
        root.addView(shell, FrameLayout.LayoutParams(MATCH, MATCH))

        // ---------- نوار بالا ----------
        val topBox = FrameLayout(this)
        header = HeaderView(this)
        topBox.addView(header, FrameLayout.LayoutParams(MATCH, MATCH))

        val topRow = LinearLayout(this)
        topRow.orientation = LinearLayout.HORIZONTAL
        topRow.gravity = Gravity.CENTER_VERTICAL
        topRow.setPadding(u(14), 0, u(14), u(6))
        statusDots = DotsView(this)
        topRow.addView(statusDots, lp(u(40), u(11)))
        netTv = txt(15f, 0)
        topRow.addView(netTv, lp(WRAP, WRAP).also { it.leftMargin = u(10) })
        wifiIcon = icon(R.drawable.ic_wifi)
        topRow.addView(wifiIcon, lp(u(22), u(22)).also { it.leftMargin = u(14) })
        gpsIcon = icon(R.drawable.ic_gps)
        topRow.addView(gpsIcon, lp(u(22), u(22)).also { it.leftMargin = u(12) })
        topRow.addView(View(this), lp(0, 1).also { it.weight = 1f })
        cloudIcon = icon(R.drawable.ic_cloud)
        topRow.addView(cloudIcon, lp(u(26), u(26)).also { it.rightMargin = u(8) })
        tempTv = txt(19f, 0)
        topRow.addView(tempTv, lp(WRAP, WRAP).also { it.rightMargin = u(8) })
        topBox.addView(topRow, FrameLayout.LayoutParams(MATCH, MATCH))

        val clockCol = LinearLayout(this)
        clockCol.orientation = LinearLayout.VERTICAL
        clockCol.gravity = Gravity.CENTER_HORIZONTAL
        clockTv = txt(38f, 0)
        dateTv = txt(14f, 1)
        clockCol.addView(clockTv, lp(WRAP, WRAP))
        clockCol.addView(dateTv, lp(WRAP, WRAP))
        topBox.addView(clockCol, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER_HORIZONTAL or Gravity.TOP))
        shell.addView(topBox, lp(MATCH, u(72)))

        val content = LinearLayout(this)
        content.orientation = LinearLayout.HORIZONTAL
        shell.addView(content, lp(MATCH, 0).also { it.weight = 1f })

        // ---------- نوار کناری ----------
        val side = LinearLayout(this)
        side.orientation = LinearLayout.VERTICAL
        side.gravity = Gravity.CENTER_HORIZONTAL
        card(side, 20, 255)
        navBtn = sideButton(R.drawable.ic_nav)
        navBtn.setOnClickListener { follow = true; recenter() }
        val musicBtn = sideButton(R.drawable.ic_music)
        musicBtn.setOnClickListener { startActivity(Intent(this, PlayerActivity::class.java)) }
        val phoneBtn = sideButton(R.drawable.ic_phone)
        phoneBtn.setOnClickListener {
            val p = prefs.phonePkg
            if (p.isNotEmpty()) {
                val i = packageManager.getLaunchIntentForPackage(p)
                if (i != null) startActivity(i) else pickApp(201)
            } else {
                try { startActivity(Intent(Intent.ACTION_DIAL)) } catch (e: Exception) { pickApp(201) }
            }
        }
        phoneBtn.setOnLongClickListener { pickApp(201); true }
        val appsBtn = sideButton(R.drawable.ic_apps)
        appsBtn.setOnClickListener { startActivity(Intent(this, AppsActivity::class.java)) }
        val setBtn = sideButton(R.drawable.ic_settings)
        setBtn.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        sideIcons = arrayOf(navBtn, musicBtn, phoneBtn, appsBtn, setBtn)
        for (b in sideIcons) {
            side.addView(b, lp(u(52), u(52)).also { it.topMargin = u(10); it.bottomMargin = u(10) })
        }
        content.addView(side, lp(u(66), MATCH).also { it.rightMargin = u(12) })

        // ---------- ستون A: نقشه + موزیک ----------
        val colA = LinearLayout(this)
        colA.orientation = LinearLayout.VERTICAL
        content.addView(colA, lp(0, MATCH).also { it.weight = 1.38f; it.rightMargin = u(12) })

        val mapCard = FrameLayout(this)
        colA.addView(mapCard, lp(MATCH, 0).also { it.weight = 1f; it.bottomMargin = u(10) })
        setupMap()
        mapCard.addView(mapView, FrameLayout.LayoutParams(MATCH, MATCH))
        mask = CornerMask(this)
        mask.radius = u(22).toFloat()
        mapCard.addView(mask, FrameLayout.LayoutParams(MATCH, MATCH))

        // کارت پیچ بعدی
        instrCard = LinearLayout(this)
        instrCard.orientation = LinearLayout.VERTICAL
        instrCard.setPadding(u(14), u(10), u(18), u(10))
        instrCard.visibility = View.GONE
        card(instrCard, 16, 0xE6)
        val ir = LinearLayout(this)
        ir.gravity = Gravity.CENTER_VERTICAL
        instrArrow = icon(R.drawable.ic_turn)
        ir.addView(instrArrow, lp(u(40), u(40)))
        instrDist = txt(30f, 0)
        ir.addView(instrDist, lp(WRAP, WRAP).also { it.leftMargin = u(10) })
        instrCard.addView(ir)
        instrText = txt(15f, 1)
        instrText.maxWidth = u(300)
        instrCard.addView(instrText, lp(WRAP, WRAP).also { it.topMargin = u(2) })
        instrCard.setOnClickListener { showDirections() }
        mapCard.addView(instrCard, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START).also {
            it.setMargins(u(12), u(12), 0, 0)
        })

        // دکمه‌های کنار نقشه: زوم، موقعیت، جستجو
        val ctrl = LinearLayout(this)
        ctrl.orientation = LinearLayout.VERTICAL
        ctrl.gravity = Gravity.CENTER_HORIZONTAL
        val zoomBox = LinearLayout(this)
        zoomBox.orientation = LinearLayout.VERTICAL
        card(zoomBox, 16, 0xE6)
        val zin = mapIconButton(R.drawable.ic_plus)
        zin.setOnClickListener { mapView.controller.zoomIn() }
        val zout = mapIconButton(R.drawable.ic_minus)
        zout.setOnClickListener { mapView.controller.zoomOut() }
        zoomBox.addView(zin, lp(u(44), u(44)))
        zoomBox.addView(zout, lp(u(44), u(44)))
        ctrl.addView(zoomBox, lp(WRAP, WRAP))
        recenterBtn = mapIconButton(R.drawable.ic_nav)
        card(recenterBtn, 22, 0xE6)
        recenterBtn.setOnClickListener { follow = true; recenter() }
        ctrl.addView(recenterBtn, lp(u(44), u(44)).also { it.topMargin = u(10) })
        val searchBtn = mapIconButton(R.drawable.ic_search)
        card(searchBtn, 22, 0xE6)
        searchBtn.setOnClickListener { openSearch() }
        ctrl.addView(searchBtn, lp(u(44), u(44)).also { it.topMargin = u(10) })
        mapCard.addView(ctrl, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.END).also {
            it.setMargins(0, u(12), u(12), 0)
        })

        attrTv = label(9f, 0x99FFFFFF.toInt())
        attrTv.text = "© OpenStreetMap contributors"
        mapCard.addView(attrTv, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.END).also {
            it.setMargins(0, 0, u(12), u(6))
        })

        // قرص پایین نقشه: زمان و مسافت یا جستجو
        pill = LinearLayout(this)
        pill.orientation = LinearLayout.HORIZONTAL
        pill.gravity = Gravity.CENTER_VERTICAL
        pill.setPadding(u(14), u(6), u(12), u(6))
        card(pill, 24, 0xE6)
        pillIcon = icon(R.drawable.ic_search)
        pill.addView(pillIcon, lp(u(26), u(26)))
        pillText = txt(17f, 0)
        pill.addView(pillText, lp(WRAP, WRAP).also { it.leftMargin = u(10) })
        pillClose = icon(R.drawable.ic_close)
        pillClose.setPadding(u(6), u(6), u(6), u(6))
        pillClose.setOnClickListener { clearRoute() }
        pill.addView(pillClose, lp(u(30), u(30)).also { it.leftMargin = u(8) })
        pill.setOnClickListener { if (route == null) openSearch() else showDirections() }
        mapCard.addView(pill, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.BOTTOM or Gravity.START).also {
            it.setMargins(u(12), 0, 0, u(12))
        })

        // ---- کارت موزیک ----
        val mc = LinearLayout(this)
        mc.orientation = LinearLayout.HORIZONTAL
        mc.gravity = Gravity.CENTER_VERTICAL
        mc.setPadding(u(12), u(10), u(14), u(10))
        card(mc, 22, 255)
        artView = CoverView(this)
        mc.addView(artView, lp(u(84), u(84)))
        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        musicTitle = txt(19f, 0)
        musicTitle.setSingleLine(true)
        musicTitle.ellipsize = TextUtils.TruncateAt.MARQUEE
        musicTitle.marqueeRepeatLimit = -1
        musicTitle.isSelected = true
        musicArtist = txt(15f, 2)
        musicArtist.setSingleLine(true)
        mid.addView(musicTitle, lp(MATCH, WRAP))
        mid.addView(musicArtist, lp(MATCH, WRAP))
        musicProgress = ProgressLine(this)
        musicProgress.onSeek = { f -> music.seek(f) }
        mid.addView(musicProgress, lp(MATCH, u(22)).also { it.topMargin = u(4) })
        val times = LinearLayout(this)
        posTv = txt(11f, 1)
        durTv = txt(11f, 1)
        times.addView(posTv, lp(0, WRAP).also { it.weight = 1f })
        times.addView(durTv, lp(WRAP, WRAP))
        mid.addView(times, lp(MATCH, WRAP))
        mc.addView(mid, lp(0, WRAP).also { it.weight = 1f; it.leftMargin = u(14); it.rightMargin = u(14) })
        val bp = mapIconButton(R.drawable.ic_prev)
        bp.setOnClickListener { music.prev() }
        btnPlay = mapIconButton(R.drawable.ic_pause)
        btnPlay.setOnClickListener { music.toggle() }
        val bn = mapIconButton(R.drawable.ic_next)
        bn.setOnClickListener { music.next() }
        mc.addView(bp, lp(u(42), u(42)))
        mc.addView(btnPlay, lp(u(58), u(58)).also { it.leftMargin = u(10); it.rightMargin = u(10) })
        mc.addView(bn, lp(u(42), u(42)))
        colA.addView(mc, lp(MATCH, u(112)))

        // ---------- ستون B: سرعت‌سنج + دکمه‌ها ----------
        val colB = LinearLayout(this)
        colB.orientation = LinearLayout.VERTICAL
        content.addView(colB, lp(0, MATCH).also { it.weight = 1.12f })

        val dialCard = FrameLayout(this)
        card(dialCard, 22, 255)
        dial = DialView(this)
        dial.onModeTap = { nextMode() }
        dialCard.addView(dial, FrameLayout.LayoutParams(MATCH, MATCH))
        colB.addView(dialCard, lp(MATCH, 0).also { it.weight = 1f; it.bottomMargin = u(10) })

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        wifiTile = makeTile(R.drawable.ic_wifi, "Wi-Fi")
        btTile = makeTile(R.drawable.ic_bluetooth, "بلوتوث")
        cabinTile = makeTile(R.drawable.ic_thermo, "دمای داخل")
        gpsTile = makeTile(R.drawable.ic_gps, "GPS")
        wifiTile.box.setOnClickListener { radios.toggleWifi(this) }
        btTile.box.setOnClickListener { radios.toggleBt(this) }
        cabinTile.box.setOnClickListener {
            toast(if (cabinFromSensor) "دما از سنسور محیطی دستگاه خوانده می‌شود." else "این دستگاه سنسور دمای کابین ندارد؛ دمای خود دستگاه نمایش داده می‌شود.")
        }
        gpsTile.box.setOnClickListener {
            try { startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)) } catch (e: Exception) { toast("باز کردن تنظیمات ممکن نشد.") }
        }
        val all = arrayOf(wifiTile, btTile, cabinTile, gpsTile)
        for (i in all.indices) {
            row.addView(all[i].box, lp(0, MATCH).also {
                it.weight = 1f
                if (i > 0) it.leftMargin = u(8)
            })
        }
        colB.addView(row, lp(MATCH, u(104)))

        sport = SportOverlay(this)
        root.addView(sport, FrameLayout.LayoutParams(MATCH, MATCH))

        setContentView(root)
        builtVersion = prefs.version
    }

    private lateinit var sideIcons: Array<ImageButton>

    private fun mapIconButton(res: Int): ImageButton {
        val b = ImageButton(this)
        b.setImageResource(res)
        b.scaleType = ImageView.ScaleType.FIT_CENTER
        b.setPadding(u(11), u(11), u(11), u(11))
        b.background = null
        mapIcons.add(b)
        return b
    }

    private val mapIcons = ArrayList<ImageButton>()

    // =====================================================================
    // تم و مود
    private fun applyTheme(t: Th) {
        th = t
        root.setBackgroundColor(t.bg)
        mask.color = t.bg
        mask.stroke = t.line
        for (i in cardViews.indices) {
            val g = GradientDrawable()
            g.setColor(withAlpha(t.card, cardAlpha[i]))
            g.setCornerRadius(u(cardRadius[i]).toFloat())
            g.setStroke(u(1), t.line)
            cardViews[i].background = g
        }
        for (x in tPrimary) x.setTextColor(t.text)
        for (x in tSub) x.setTextColor(t.sub)
        for (x in tAccent) x.setTextColor(t.c1)
        for (x in iPrimary) x.setColorFilter(t.text)
        for (i in sideIcons.indices) sideIcons[i].setColorFilter(if (i == 0) t.c1 else t.sub)
        val nb = GradientDrawable()
        nb.setColor(withAlpha(t.c1, 0x33))
        nb.setCornerRadius(u(14).toFloat())
        nb.setStroke(u(1), withAlpha(t.c1, 0x99))
        navBtn.background = nb
        for (b in mapIcons) b.setColorFilter(t.text)
        recenterBtn.setColorFilter(t.c1)
        val pg = GradientDrawable()
        pg.setShape(GradientDrawable.OVAL)
        pg.setColor(withAlpha(t.c1, 0x22))
        pg.setStroke(u(2), t.c1)
        btnPlay.background = pg
        musicProgress.accent = t.c1
        musicProgress.track = withAlpha(t.sub, 0x66)
        musicProgress.thumb = t.c3
        artView.accent = t.c1
        for (tile in tiles) tile.icon.setColorFilter(if (tile.on) t.c1 else t.sub)
        dial.setColors(t)
        header.setColors(t)
        routeLine.outlinePaint.color = t.c1
        mapView.invalidate()
    }

    private fun nextMode() {
        setMode((modeIdx + 1) % 4, true)
    }

    private fun setMode(i: Int, animate: Boolean) {
        val from = th
        val to = Themes.ALL[i]
        modeIdx = i
        prefs.driveMode = i
        prefs.lastAccent = to.c1
        sim.mode = i
        dial.modeCount = 4
        dial.changeMode(to.name, i, animate)
        applyMapStyle()
        themeAnim?.cancel()
        if (!animate) {
            applyTheme(to)
            refreshMarkers()
            return
        }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 800
        a.addUpdateListener { applyTheme(Themes.blend(from, to, it.animatedValue as Float)) }
        a.start()
        themeAnim = a
        handler.postDelayed({ refreshMarkers() }, 850)
    }

    // =====================================================================
    // نقشه
    private fun arrowBitmap(color: Int): Bitmap {
        val s = u(56)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val path = Path()
        val f = s.toFloat()
        path.moveTo(f / 2f, f * 0.06f)
        path.lineTo(f * 0.90f, f * 0.92f)
        path.lineTo(f / 2f, f * 0.72f)
        path.lineTo(f * 0.10f, f * 0.92f)
        path.close()
        p.color = color
        p.style = Paint.Style.FILL
        c.drawPath(path, p)
        p.color = Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = f * 0.07f
        c.drawPath(path, p)
        return bmp
    }

    private fun pinBitmap(color: Int): Bitmap {
        val s = u(34)
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        val f = s.toFloat()
        p.color = Color.WHITE
        c.drawCircle(f / 2, f / 2, f * 0.46f, p)
        p.color = color
        c.drawCircle(f / 2, f / 2, f * 0.34f, p)
        p.color = Color.WHITE
        c.drawCircle(f / 2, f / 2, f * 0.12f, p)
        return bmp
    }

    private fun refreshMarkers() {
        carMarker.icon = BitmapDrawable(resources, arrowBitmap(th.c1))
        destMarker.icon = BitmapDrawable(resources, pinBitmap(th.c3))
        mapView.invalidate()
    }

    private fun setupMap() {
        mapView = MapView(this)
        mapView.setMultiTouchControls(true)
        mapView.zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
        mapView.setTilesScaledToDpi(true)
        mapView.setMinZoomLevel(3.0)
        mapView.setMaxZoomLevel(19.0)
        mapView.setTileSource(TileSourceFactory.MAPNIK)
        mapView.controller.setZoom(3.5)

        routeLine = Polyline()
        routeLine.outlinePaint.color = th.c1
        routeLine.outlinePaint.strokeWidth = u(8).toFloat()
        routeLine.outlinePaint.strokeCap = Paint.Cap.ROUND
        routeLine.outlinePaint.strokeJoin = Paint.Join.ROUND
        mapView.overlays.add(routeLine)

        destMarker = Marker(mapView)
        destMarker.icon = BitmapDrawable(resources, pinBitmap(th.c3))
        destMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        destMarker.setInfoWindow(null)

        carMarker = Marker(mapView)
        carMarker.icon = BitmapDrawable(resources, arrowBitmap(th.c1))
        carMarker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
        carMarker.setInfoWindow(null)
        mapView.overlays.add(carMarker)

        val ll = lastKnown()
        if (ll != null) {
            carMarker.position = GeoPoint(ll.latitude, ll.longitude)
            mapView.controller.setZoom(15.5)
            mapView.controller.setCenter(carMarker.position)
            firstFix = true
        }

        mapView.setOnTouchListener { _, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.x
                    downY = ev.y
                    cancelLong()
                    val r = Runnable { onMapLongPress(downX, downY) }
                    longRun = r
                    handler.postDelayed(r, 750)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (abs(ev.x - downX) > u(14) || abs(ev.y - downY) > u(14)) {
                        cancelLong()
                        if (follow) {
                            follow = false
                            recenterBtn.alpha = 1f
                        }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL, MotionEvent.ACTION_POINTER_DOWN -> cancelLong()
            }
            false
        }
    }

    private fun cancelLong() {
        val r = longRun
        if (r != null) handler.removeCallbacks(r)
        longRun = null
    }

    private fun applyMapStyle() {
        val dark = when (prefs.mapStyle) {
            1 -> true
            2 -> false
            else -> Themes.ALL[modeIdx].dark
        }
        mapView.overlayManager.tilesOverlay.setColorFilter(if (dark) TilesOverlay.INVERT_COLORS else null)
        mapView.invalidate()
    }

    private fun recenter() {
        val l = lastLoc
        if (l != null) {
            mapView.controller.animateTo(GeoPoint(l.latitude, l.longitude))
        } else {
            val ll = lastKnown()
            if (ll != null) mapView.controller.animateTo(GeoPoint(ll.latitude, ll.longitude))
        }
        recenterBtn.alpha = 0.7f
    }

    private fun onMapLongPress(x: Float, y: Float) {
        val gp = mapView.projection.fromPixels(x.toInt(), y.toInt())
        val lat = gp.latitude
        val lon = gp.longitude
        Thread {
            val d = try { Nav.reverse(lat, lon) } catch (e: Exception) { Dest("نقطه‌ی انتخابی", "", lat, lon) }
            runOnUiThread {
                AlertDialog.Builder(this)
                    .setTitle("مسیریابی به این نقطه؟")
                    .setMessage(d.name)
                    .setPositiveButton("بله") { _, _ -> startRoute(d) }
                    .setNegativeButton("خیر", null)
                    .show()
            }
        }.start()
    }

    // =====================================================================
    // مسیریابی
    private fun openSearch() {
        val i = Intent(this, SearchActivity::class.java)
        val l = lastLoc ?: lastKnown()
        if (l != null) {
            i.putExtra("lat", l.latitude)
            i.putExtra("lon", l.longitude)
        }
        startActivityForResult(i, 500)
    }

    private fun startRoute(d: Dest) {
        val l = lastLoc ?: lastKnown()
        val fLat: Double
        val fLon: Double
        if (l != null) {
            fLat = l.latitude
            fLon = l.longitude
        } else {
            val c = mapView.mapCenter
            fLat = c.latitude
            fLon = c.longitude
        }
        dest = d
        pillText.setFa("در حال مسیریابی...")
        Thread {
            try {
                val r = Nav.route(fLat, fLon, d.lat, d.lon)
                runOnUiThread {
                    if (r == null) {
                        toast("مسیری پیدا نشد.")
                        clearRoute()
                    } else {
                        applyRoute(r, d, true)
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    toast("خطا در مسیریابی. اینترنت را بررسی کنید.")
                    clearRoute()
                }
            }
        }.start()
    }

    private fun applyRoute(r: Route, d: Dest, overview: Boolean) {
        route = r
        tracker = RouteTracker(r)
        val pts = ArrayList<GeoPoint>()
        for (i in r.lats.indices) pts.add(GeoPoint(r.lats[i], r.lons[i]))
        routeLine.setPoints(pts)
        destMarker.position = GeoPoint(d.lat, d.lon)
        if (!destOnMap) {
            mapView.overlays.add(mapView.overlays.size - 1, destMarker)
            destOnMap = true
        }
        pillIcon.setImageResource(R.drawable.ic_car)
        pillClose.visibility = View.VISIBLE
        instrCard.visibility = View.VISIBLE
        if (overview) {
            follow = false
            mapView.mapOrientation = 0f
            orient = 0f
            try {
                mapView.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, u(80))
            } catch (e: Exception) {
            }
            handler.postDelayed({
                if (route != null) {
                    follow = true
                    recenter()
                }
            }, 6000)
        }
        val l = lastLoc
        if (l != null) {
            showProgress(RouteTracker(r).update(l.latitude, l.longitude, l.accuracy))
        } else {
            showProgress(Progress(0, r.distance, r.duration, 0.0, r.steps.getOrNull(1)?.startDist ?: 0.0, r.steps.getOrNull(1)))
        }
        mapView.invalidate()
    }

    private fun clearRoute() {
        route = null
        tracker = null
        dest = null
        routeLine.setPoints(ArrayList<GeoPoint>())
        if (destOnMap) {
            mapView.overlays.remove(destMarker)
            destOnMap = false
        }
        instrCard.visibility = View.GONE
        pillIcon.setImageResource(R.drawable.ic_search)
        pillText.setFa("جستجوی مقصد")
        pillClose.visibility = View.GONE
        mapView.invalidate()
    }

    private fun reroute() {
        val d = dest ?: return
        val l = lastLoc ?: return
        lastReroute = SystemClock.elapsedRealtime()
        Thread {
            try {
                val r = Nav.route(l.latitude, l.longitude, d.lat, d.lon)
                if (r != null) runOnUiThread { applyRoute(r, d, false) }
            } catch (e: Exception) {
            }
        }.start()
    }

    private fun showProgress(p: Progress) {
        val nx = p.next
        if (nx != null) {
            instrArrow.rotation = Nav.arrowAngle(nx.type, nx.modifier)
            instrDist.setFa(Nav.fmtDist(p.distToNext), true)
            instrText.setFa(nx.text)
        }
        val eta = Date(System.currentTimeMillis() + (p.remainingTime * 1000).toLong())
        val fmt = SimpleDateFormat(if (prefs.clock24) "HH:mm" else "hh:mm a", Locale.ENGLISH)
        pillText.setFa(Nav.fmtDur(p.remainingTime) + "  |  " + Nav.fmtDist(p.remaining) + "  |  " + fmt.format(eta), true)
    }

    private fun showDirections() {
        val r = route ?: return
        val items = r.steps.map { Nav.fmtDist(it.dist) + "   " + it.text }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle(dest?.name ?: "مسیر")
            .setItems(items) { _, _ -> }
            .show()
    }

    // =====================================================================
    // موقعیت
    private fun handleLocation(l: Location) {
        lastLoc = l
        lastLocAt = SystemClock.elapsedRealtime()
        curKmh = if (l.hasSpeed()) l.speed * 3.6f else 0f
        if (curKmh < 3f) curKmh = 0f
        val gp = GeoPoint(l.latitude, l.longitude)
        carMarker.position = gp
        if (!firstFix) {
            firstFix = true
            mapView.controller.setZoom(16.0)
            mapView.controller.setCenter(gp)
        }
        if (follow) {
            mapView.controller.animateTo(gp)
            if (!prefs.northUp && l.hasBearing() && l.speed > 1.5f) {
                val tgt = -l.bearing
                val diff = ((tgt - orient + 540f) % 360f) - 180f
                orient += diff * 0.35f
                mapView.mapOrientation = orient
            }
        }
        val tr = tracker
        if (tr != null) {
            val p = tr.update(l.latitude, l.longitude, l.accuracy)
            showProgress(p)
            val now = SystemClock.elapsedRealtime()
            if (p.offCount >= 3 && now - lastReroute > 12000) reroute()
            val nx = p.next
            if (p.remaining < 35 && nx != null && nx.type == "arrive") {
                toast("به مقصد رسیدید")
                clearRoute()
            }
        }
        mapView.invalidate()
    }

    private fun granted(p: String) =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun requestPerms() {
        if (Build.VERSION.SDK_INT < 23 || askedPerms) return
        askedPerms = true
        val need = listOf(Manifest.permission.ACCESS_FINE_LOCATION, music.audioPerm()).filter { !granted(it) }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        music.loadIfPermitted()
        startLocation()
    }

    private fun startLocation() {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) return
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            locationManager = lm
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, locListener)
            }
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000L, 0f, locListener)
            }
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }

    private fun stopLocation() {
        try { locationManager?.removeUpdates(locListener) } catch (_: Exception) {}
    }

    private fun lastKnown(): Location? {
        if (!granted(Manifest.permission.ACCESS_FINE_LOCATION)) return null
        return try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            lm.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
        } catch (e: Exception) {
            null
        }
    }

    // =====================================================================
    // تنظیمات
    private fun applyPrefs() {
        builtVersion = prefs.version
        modeIdx = prefs.driveMode.coerceIn(0, 3)
        sim.mode = modeIdx
        if (prefs.speedUnit == 1) {
            dial.maxValue = 180f
            dial.labelStep = 20
            dial.minorStep = 10
            dial.unit = "mph"
        } else {
            dial.maxValue = 280f
            dial.labelStep = 40
            dial.minorStep = 10
            dial.unit = "km/h"
        }
        cloudIcon.visibility = if (prefs.showWeather) View.VISIBLE else View.GONE
        tempTv.visibility = if (prefs.showWeather) View.VISIBLE else View.GONE
        dial.modeCount = 4
        dial.changeMode(Themes.ALL[modeIdx].name, modeIdx, false)
        applyTheme(Themes.ALL[modeIdx])
        applyMapStyle()
        refreshMarkers()
        sportTarget = -1f
        if (!prefs.sportFx) applySport(0f)
        if (route == null) clearRoute()
    }

    // افکت قرمز شدن لبه‌ها با سرعت (قابل خاموش شدن در تنظیمات)
    private fun updateSport(kmh: Float) {
        val t = if (prefs.sportFx) ((kmh - 40f) / 90f).coerceIn(0f, 1f) else 0f
        if (abs(t - sportTarget) < 0.03f) return
        sportTarget = t
        sportAnim?.cancel()
        val a = ValueAnimator.ofFloat(sportT, t)
        a.duration = 900
        a.addUpdateListener { applySport(it.animatedValue as Float) }
        a.start()
        sportAnim = a
    }

    private fun applySport(t: Float) {
        sportT = t
        sport.t = t
    }

    // =====================================================================
    // شبیه‌ساز دور موتور و گیربکس CVT
    private fun demoSpeed(dt: Float): Float {
        demoT += dt
        when (demoPhase) {
            0 -> { demoV += 9f * dt; if (demoV >= 125f) { demoPhase = 1; demoT = 0f } }
            1 -> { if (demoT > 4f) demoPhase = 2 }
            2 -> { demoV -= 12f * dt; if (demoV <= 35f) { demoPhase = 3; demoT = 0f } }
            3 -> { demoV += 4f * dt; if (demoV >= 70f) { demoPhase = 4; demoT = 0f } }
            4 -> { if (demoT > 3f) demoPhase = 5 }
            5 -> { demoV -= 8f * dt; if (demoV <= 0f) { demoV = 0f; demoPhase = 6; demoT = 0f } }
            6 -> { if (demoT > 2f) demoPhase = 0 }
        }
        return demoV
    }

    private fun simStep() {
        val now = SystemClock.uptimeMillis()
        val dt = ((now - lastSimT).coerceIn(10L, 200L)) / 1000f
        lastSimT = now
        if (!prefs.demoMode && lastLoc != null && SystemClock.elapsedRealtime() - lastLocAt > 5000) curKmh = 0f
        val src = if (prefs.demoMode) demoSpeed(dt) else curKmh
        spdSm += (src - spdSm) * min(1f, dt * 3.0f)
        if (spdSm < 0.3f && src == 0f) spdSm = 0f
        val rpm = sim.update(spdSm, dt)
        val shown = if (prefs.speedUnit == 1) spdSm * 0.621371f else spdSm
        dial.setSpeed(shown)
        dial.setRpm(rpm)
        dial.gear = sim.gear
        updateSport(spdSm)
    }

    // =====================================================================
    // تیک دوره‌ای
    private fun readCabinTemp() {
        val ts = tempSensor
        if (ts != null) {
            cabinFromSensor = true
            return
        }
        cabinFromSensor = false
        val now = SystemClock.elapsedRealtime()
        if (now - lastBatteryRead < 15000) return
        lastBatteryRead = now
        try {
            val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
                if (t > -1) cabinTemp = t / 10f
            }
        } catch (_: Exception) {
        }
    }

    private fun tick() {
        val fmt = SimpleDateFormat(if (prefs.clock24) "HH:mm" else "hh:mm a", Locale.ENGLISH)
        clockTv.setFa(fmt.format(Date()), true)
        dateTv.setFa(dateText(prefs.dateMode))
        dateTv.visibility = if (prefs.dateMode == 0) View.GONE else View.VISIBLE

        val wOn = radios.wifiOn()
        val bOn = radios.btOn()
        setTile(wifiTile, wOn, if (wOn) (radios.ssid() ?: "روشن") else "خاموش")
        setTile(btTile, bOn, if (bOn) "روشن" else "خاموش")
        wifiIcon.alpha = if (wOn) 1f else 0.3f
        val net = radios.network()
        netTv.setFa(net.first)
        statusDots.level = net.second

        readCabinTemp()
        val ct = cabinTemp
        cabinTile.title.setFa(if (cabinFromSensor) "دمای داخل" else "دمای دستگاه")
        setTile(cabinTile, ct != null, if (ct != null) String.format(Locale.US, "%.1f°C", ct) else "نامشخص")

        var gpsOn = false
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            gpsOn = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        } catch (_: Exception) {
        }
        val l = lastLoc
        val fresh = l != null && SystemClock.elapsedRealtime() - lastLocAt < 6000
        val gv = if (!gpsOn) "خاموش" else if (fresh && l != null) "±" + l.accuracy.roundToInt() + " m" else "جستجو..."
        setTile(gpsTile, gpsOn && fresh, gv)
        gpsIcon.alpha = if (gpsOn) 1f else 0.3f

        updateMusic()
        maybeWeather()
    }

    private fun updateMusic() {
        music.decide()
        musicTitle.setFa(music.title.uppercase(), true)
        musicArtist.setFa(music.artist)
        btnPlay.setImageResource(if (music.playing) R.drawable.ic_pause else R.drawable.ic_play)
        val d = music.dur
        val p = music.pos
        if (!musicProgress.dragging) musicProgress.fraction = if (d > 0) p.toFloat() / d else 0f
        posTv.setFa(formatTime(p))
        durTv.setFa(if (d > 0) formatTime(d) else "")
        updateArt()
    }

    private fun updateArt() {
        if (music.useExt) {
            val a = music.ext.art
            val key = "E" + music.title + (a != null)
            if (key != artKey) {
                artKey = key
                artView.bitmap = a
            }
        } else {
            val t = music.svc?.currentTrack
            val key = if (t == null) "none" else "L" + t.id
            if (key != artKey) {
                artKey = key
                if (t == null) {
                    artView.bitmap = null
                } else {
                    Thread {
                        val b = ArtLoader.load(this, t)
                        runOnUiThread { if (artKey == key) artView.bitmap = b }
                    }.start()
                }
            }
        }
    }

    private fun maybeWeather() {
        if (!prefs.showWeather) return
        val now = SystemClock.elapsedRealtime()
        if (weatherAt != 0L && now - weatherAt < 30 * 60 * 1000L) return
        val loc = lastLoc ?: lastKnown() ?: return
        weatherAt = now
        Thread {
            try {
                val url = URL(
                    "https://api.open-meteo.com/v1/forecast?latitude=" + loc.latitude + "&longitude=" + loc.longitude +
                        "&current=temperature_2m"
                )
                val c = url.openConnection() as HttpURLConnection
                c.connectTimeout = 8000
                c.readTimeout = 8000
                val txt = c.inputStream.bufferedReader().readText()
                c.disconnect()
                val temp = JSONObject(txt).getJSONObject("current").getDouble("temperature_2m").roundToInt()
                runOnUiThread { tempTv.setFa("" + temp + "°C", true) }
            } catch (e: Exception) {
                weatherAt = now - 25 * 60 * 1000L
            }
        }.start()
    }

    // =====================================================================
    private fun pickApp(req: Int) {
        startActivityForResult(Intent(this, AppsActivity::class.java).putExtra(AppsActivity.EXTRA_PICK, true), req)
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (res != RESULT_OK || data == null) return
        if (req == 201) {
            val pkg = data.getStringExtra(AppsActivity.EXTRA_PKG)
            if (pkg != null) prefs.phonePkg = pkg
        } else if (req == 500) {
            val d = Dest(
                data.getStringExtra("name") ?: "",
                data.getStringExtra("addr") ?: "",
                data.getDoubleExtra("lat", 0.0),
                data.getDoubleExtra("lon", 0.0)
            )
            startRoute(d)
        }
    }
}
