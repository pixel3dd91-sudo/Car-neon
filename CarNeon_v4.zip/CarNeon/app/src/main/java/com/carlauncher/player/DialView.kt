package com.carlauncher.player

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * سرعت‌سنج نئونی + دور موتور (سمت راست) + دکمه‌ی چرخان تغییر مود رانندگی زیر km/h.
 * همه‌ی رنگ‌ها از تم فعلی می‌آیند.
 */
class DialView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {

    var c1 = 0xFF2F8BFF.toInt()
    var c2 = 0xFF1E5FD6.toInt()
    var c3 = 0xFF6CB8FF.toInt()
    var textC = Color.WHITE
    var subC = 0xFF93A3C0.toInt()
    var cardC = 0xFF0B1424.toInt()
    var lineC = 0x663F7BE0

    var maxValue = 280f
    var labelStep = 40
    var minorStep = 10
    var unit = "km/h"
    var gear = 1
    var modeName = "NORMAL"
    var modeIndex = 0
    var modeCount = 4
    var onModeTap: (() -> Unit)? = null

    private var speed = 0f
    private var rpm = 800f
    private var prevName = "NORMAL"
    private var flip = 1f
    private var pulse = 1f
    private var anim: ValueAnimator? = null
    private val modeRect = RectF()

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG)
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val rect = RectF()
    private val mtx = Matrix()

    init {
        stroke.style = Paint.Style.STROKE
        txt.textAlign = Paint.Align.CENTER
    }

    fun setColors(t: Th) {
        c1 = t.c1
        c2 = t.c2
        c3 = t.c3
        textC = t.text
        subC = t.sub
        cardC = t.card
        lineC = t.line
        invalidate()
    }

    fun setSpeed(v: Float) {
        val s = max(0f, v)
        if (abs(s - speed) > 0.04f) {
            speed = s
            invalidate()
        }
    }

    fun setRpm(v: Float) {
        if (abs(v - rpm) > 3f) {
            rpm = v
            invalidate()
        }
    }

    fun changeMode(name: String, idx: Int, animate: Boolean) {
        prevName = if (animate) modeName else name
        modeName = name
        modeIndex = idx
        anim?.cancel()
        if (!animate) {
            flip = 1f
            pulse = 1f
            invalidate()
            return
        }
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = 700
        a.addUpdateListener {
            flip = it.animatedValue as Float
            pulse = flip
            invalidate()
        }
        a.start()
        anim = a
    }

    private fun isLight(): Boolean = Color.red(cardC) + Color.green(cardC) + Color.blue(cardC) > 600

    private fun ptX(cx: Float, r: Float, a: Float): Float = cx + (cos(Math.toRadians(a.toDouble())) * r).toFloat()
    private fun ptY(cy: Float, r: Float, a: Float): Float = cy + (sin(Math.toRadians(a.toDouble())) * r).toFloat()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val m = context.u(8).toFloat()
        val rr = min((h - 2 * m) / 2f, (w - 2 * m) / 2.78f)
        val cx = m + rr
        val cy = h / 2f
        drawRpm(c, cx + rr * 1.12f, cy, rr * 0.66f, rr, cx)
        drawMain(c, cx, cy, rr)
    }

    // ------------------------------------------------------------------
    private fun drawRpm(c: Canvas, cx2: Float, cy: Float, r2: Float, rr: Float, cx: Float) {
        val a0 = 72f
        val span = 144f
        rect.set(cx2 - r2, cy - r2, cx2 + r2, cy + r2)

        stroke.shader = null
        stroke.alpha = 255
        stroke.color = lineC
        stroke.strokeWidth = context.u(3).toFloat()
        c.drawArc(rect, a0, -span, false, stroke)

        val frac = (rpm / 8000f).coerceIn(0f, 1f)
        if (frac > 0f) {
            stroke.shader = LinearGradient(
                0f, cy + r2, 0f, cy - r2,
                intArrayOf(c1, c2, c3, 0xFFFF2D55.toInt()), floatArrayOf(0f, 0.45f, 0.82f, 1f), Shader.TileMode.CLAMP
            )
            val ws = floatArrayOf(2.4f, 1.6f, 1f)
            val al = intArrayOf(34, 80, 255)
            for (i in 0 until 3) {
                stroke.strokeWidth = r2 * 0.13f * ws[i]
                stroke.alpha = al[i]
                c.drawArc(rect, a0, -span * frac, false, stroke)
            }
            stroke.shader = null
            stroke.alpha = 255
        }

        // درجه‌ها و عددها (۰ تا ۸)
        for (i in 0..16) {
            val v = i * 500
            val a = a0 - span * v / 8000f
            val major = i % 2 == 0
            val rIn = if (major) r2 * 0.80f else r2 * 0.86f
            stroke.strokeWidth = context.u(if (major) 2 else 1).toFloat()
            stroke.color = if (v >= 7000) 0xFFFF2D55.toInt() else (if (major) textC else subC)
            c.drawLine(ptX(cx2, rIn, a), ptY(cy, rIn, a), ptX(cx2, r2 * 0.92f, a), ptY(cy, r2 * 0.92f, a), stroke)
        }
        txt.typeface = Fonts.forText(context, "0", false)
        txt.textSize = r2 * 0.17f
        for (i in 0..8) {
            val a = a0 - span * i / 8f
            txt.color = if (i >= 7) 0xFFFF2D55.toInt() else subC
            c.drawText("" + i, ptX(cx2, r2 * 0.66f, a), ptY(cy, r2 * 0.66f, a) + txt.textSize * 0.35f, txt)
        }

        // متن‌ها
        val tx = cx + rr * 1.20f
        txt.color = subC
        txt.textSize = rr * 0.075f
        c.drawText("RPM", tx, cy - rr * 0.14f, txt)
        txt.typeface = Fonts.forText(context, "0", true)
        txt.color = textC
        txt.textSize = rr * 0.15f
        c.drawText("" + ((rpm / 10f).roundToInt() * 10), tx, cy + rr * 0.04f, txt)
        txt.typeface = Fonts.forText(context, "0", false)
        txt.color = subC
        txt.textSize = rr * 0.07f
        c.drawText("x1000", tx, cy + rr * 0.17f, txt)
        txt.typeface = Fonts.forText(context, "0", true)
        txt.color = c1
        txt.textSize = rr * 0.10f
        c.drawText("D" + gear, tx, cy + rr * 0.34f, txt)
    }

    // ------------------------------------------------------------------
    private fun drawMain(c: Canvas, cx: Float, cy: Float, rr: Float) {
        // بدنه
        fill.style = Paint.Style.FILL
        fill.shader = RadialGradient(
            cx, cy, rr, intArrayOf(cardC, blendColors(cardC, c2, if (isLight()) 0.10f else 0.20f)),
            null, Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, rr, fill)
        fill.shader = null
        stroke.shader = null
        stroke.alpha = 255
        stroke.color = lineC
        stroke.strokeWidth = context.u(2).toFloat()
        c.drawCircle(cx, cy, rr, stroke)

        val ra = rr * 0.935f
        rect.set(cx - ra, cy - ra, cx + ra, cy + ra)
        stroke.color = lineC
        stroke.strokeWidth = rr * 0.022f
        c.drawArc(rect, 135f, 270f, false, stroke)

        // کمان رنگی با درخشش
        val frac = (speed / maxValue).coerceIn(0f, 1f)
        if (frac > 0f) {
            val sg = SweepGradient(cx, cy, intArrayOf(c1, c2, c3, c3), floatArrayOf(0f, 0.375f, 0.75f, 1f))
            mtx.reset()
            mtx.setRotate(135f, cx, cy)
            sg.setLocalMatrix(mtx)
            stroke.shader = sg
            val ws = floatArrayOf(3.2f, 1.9f, 1f)
            val al = intArrayOf(36, 84, 255)
            for (i in 0 until 3) {
                stroke.strokeWidth = rr * 0.075f * ws[i]
                stroke.alpha = al[i]
                c.drawArc(rect, 135f, 270f * frac, false, stroke)
            }
            stroke.shader = null
            stroke.alpha = 255
        }

        // درجه‌ها
        val maxI = maxValue.toInt()
        var v = 0
        while (v <= maxI) {
            val a = 135f + 270f * v / maxValue
            val major = v % labelStep == 0
            val rIn = if (major) rr * 0.79f else rr * 0.84f
            stroke.strokeWidth = context.u(if (major) 2 else 1).toFloat()
            stroke.color = if (major) textC else subC
            c.drawLine(ptX(cx, rIn, a), ptY(cy, rIn, a), ptX(cx, rr * 0.875f, a), ptY(cy, rr * 0.875f, a), stroke)
            v += minorStep
        }
        // عددها
        txt.typeface = Fonts.forText(context, "0", false)
        txt.textSize = rr * 0.10f
        txt.color = textC
        v = 0
        while (v <= maxI) {
            val a = 135f + 270f * v / maxValue
            c.drawText("" + v, ptX(cx, rr * 0.67f, a), ptY(cy, rr * 0.67f, a) + txt.textSize * 0.35f, txt)
            v += labelStep
        }

        // عقربه
        val needle = if (isLight()) c3 else blendColors(c1, Color.WHITE, 0.65f)
        val na = 135f + 270f * frac
        stroke.color = needle
        stroke.strokeWidth = context.u(3).toFloat()
        c.drawLine(ptX(cx, rr * 0.80f, na), ptY(cy, rr * 0.80f, na), ptX(cx, rr * 0.985f, na), ptY(cy, rr * 0.985f, na), stroke)

        // دایره‌ی وسط
        fill.color = blendColors(cardC, c2, 0.06f)
        c.drawCircle(cx, cy, rr * 0.55f, fill)
        stroke.color = lineC
        stroke.strokeWidth = context.u(2).toFloat()
        c.drawCircle(cx, cy, rr * 0.55f, stroke)

        // عدد سرعت و واحد
        val base = Fonts.forText(context, "0", true)
        txt.typeface = Typeface.create(base, Typeface.BOLD_ITALIC)
        txt.color = textC
        txt.textSize = rr * 0.46f
        c.drawText("" + speed.roundToInt(), cx, cy + rr * 0.15f, txt)
        txt.typeface = Fonts.forText(context, "0", false)
        txt.color = subC
        txt.textSize = rr * 0.12f
        c.drawText(unit, cx, cy + rr * 0.37f, txt)

        // خطوط جاده زیر دایره
        stroke.strokeWidth = context.u(2).toFloat()
        val ly = cy + rr * 0.80f
        val lines = floatArrayOf(0.62f, 0.38f, 0.16f)
        for (i in lines.indices) {
            stroke.color = if (i == 0) c2 else c3
            stroke.alpha = 150
            c.drawLine(cx - rr * lines[i], cy + rr * 1.0f, cx - rr * 0.05f, cy + rr * 0.62f, stroke)
            c.drawLine(cx + rr * lines[i], cy + rr * 1.0f, cx + rr * 0.05f, cy + rr * 0.62f, stroke)
        }
        stroke.alpha = 255

        // دکمه‌ی مود: برچسب با چرخش (flip)، پیکان‌ها و نقطه‌های حالت
        val labelW = rr * 0.95f
        val labelH = rr * 0.26f
        modeRect.set(cx - labelW / 2, ly - labelH / 2, cx + labelW / 2, ly + labelH / 2)
        modeRect.inset(-rr * 0.08f, -rr * 0.08f)

        val sc = max(0.06f, abs(cos(Math.PI * flip)).toFloat())
        val name = if (flip < 0.5f) prevName else modeName
        c.save()
        c.scale(1f, sc, cx, ly)
        // پیکان‌های // و \\
        for (side in intArrayOf(-1, 1)) {
            for (j in 0 until 2) {
                val x = cx + side * (rr * 0.34f + j * rr * 0.065f)
                val hh = rr * 0.10f
                val sk = rr * 0.04f * side
                path.reset()
                path.moveTo(x - sk, ly + hh)
                path.lineTo(x - sk + rr * 0.035f, ly + hh)
                path.lineTo(x + sk + rr * 0.035f, ly - hh)
                path.lineTo(x + sk, ly - hh)
                path.close()
                fill.color = c3
                fill.alpha = if (j == 0) 255 else 150
                c.drawPath(path, fill)
            }
        }
        fill.alpha = 255
        txt.typeface = Typeface.create(Fonts.forText(context, "A", true), Typeface.BOLD_ITALIC)
        txt.color = c3
        txt.textSize = rr * 0.17f
        c.drawText(name, cx, ly + txt.textSize * 0.35f, txt)
        c.restore()

        // نقطه‌های مود
        val dy = ly + rr * 0.19f
        for (i in 0 until modeCount) {
            val x = cx + (i - (modeCount - 1) / 2f) * rr * 0.085f
            fill.color = if (i == modeIndex) c3 else lineC
            c.drawCircle(x, dy, rr * (if (i == modeIndex) 0.026f else 0.018f), fill)
        }

        // موج هنگام تغییر مود
        if (pulse < 1f) {
            stroke.color = c3
            stroke.alpha = (255 * (1f - pulse)).toInt().coerceIn(0, 255)
            stroke.strokeWidth = context.u(3).toFloat()
            c.drawCircle(cx, ly, rr * (0.12f + 0.80f * pulse), stroke)
            stroke.alpha = 255
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val inside = modeRect.contains(e.x, e.y)
        if (e.action == MotionEvent.ACTION_UP && inside) {
            onModeTap?.invoke()
            return true
        }
        return inside
    }
}

// ======================================================================
/** خطوط نئونی دکوراتیو بالای صفحه، دو طرف ساعت */
class HeaderView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    var c1 = 0xFF2F8BFF.toInt()
    var c2 = 0xFF1E5FD6.toInt()
    var c3 = 0xFF6CB8FF.toInt()
    var lineC = 0x663F7BE0

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    init {
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
    }

    fun setColors(t: Th) {
        c1 = t.c1
        c2 = t.c2
        c3 = t.c3
        lineC = t.line
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = null
        p.color = lineC
        p.alpha = 90
        p.strokeWidth = context.u(1).toFloat()
        c.drawLine(0f, h * 0.10f, w, h * 0.10f, p)

        // خط چپ
        path.reset()
        path.moveTo(w * 0.17f, h * 0.80f)
        path.lineTo(w * 0.355f, h * 0.80f)
        path.lineTo(w * 0.405f, h * 0.99f)
        p.shader = LinearGradient(w * 0.17f, 0f, w * 0.40f, 0f, c1, c2, Shader.TileMode.CLAMP)
        val ws = floatArrayOf(4f, 2.4f, 1f)
        val al = intArrayOf(30, 70, 255)
        for (i in 0 until 3) {
            p.strokeWidth = context.u(2).toFloat() * ws[i]
            p.alpha = al[i]
            c.drawPath(path, p)
        }
        // خط راست
        path.reset()
        path.moveTo(w * 0.83f, h * 0.80f)
        path.lineTo(w * 0.645f, h * 0.80f)
        path.lineTo(w * 0.595f, h * 0.99f)
        p.shader = LinearGradient(w * 0.83f, 0f, w * 0.60f, 0f, c3, c2, Shader.TileMode.CLAMP)
        for (i in 0 until 3) {
            p.strokeWidth = context.u(2).toFloat() * ws[i]
            p.alpha = al[i]
            c.drawPath(path, p)
        }
        p.shader = null
        p.alpha = 255
    }
}
