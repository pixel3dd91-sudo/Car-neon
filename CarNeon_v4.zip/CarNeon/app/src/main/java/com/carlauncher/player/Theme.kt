package com.carlauncher.player

/** یک تم رنگی کامل برای هر حالت رانندگی */
class Th(
    val name: String,
    val bg: Int, val card: Int,
    val c1: Int, val c2: Int, val c3: Int,
    val text: Int, val sub: Int, val line: Int,
    val dark: Boolean
)

object Themes {
    // ترتیب چرخش دکمه: نرمال ← اسپرت ← برفی ← کم‌مصرف
    val NORMAL = Th(
        "NORMAL", 0xFF050912.toInt(), 0xFF0B1424.toInt(),
        0xFF2F8BFF.toInt(), 0xFF1E5FD6.toInt(), 0xFF6CB8FF.toInt(),
        0xFFFFFFFF.toInt(), 0xFF93A3C0.toInt(), 0x663F7BE0, true
    )
    val SPORT = Th(
        "SPORT", 0xFF04050C.toInt(), 0xFF0B0A1E.toInt(),
        0xFF19D6FF.toInt(), 0xFF7A3CFF.toInt(), 0xFFE23CFF.toInt(),
        0xFFFFFFFF.toInt(), 0xFF9C9FD0.toInt(), 0x668A5CFF, true
    )
    val SNOW = Th(
        "SNOW", 0xFFE8EFF7.toInt(), 0xFFFFFFFF.toInt(),
        0xFF4FA3E8.toInt(), 0xFF9CCBEF.toInt(), 0xFF2E7FC9.toInt(),
        0xFF13233B.toInt(), 0xFF6B7C93.toInt(), 0x669CCBEF, false
    )
    val ECO = Th(
        "ECO", 0xFF030D08.toInt(), 0xFF08170F.toInt(),
        0xFF2CFF8F.toInt(), 0xFF00B85C.toInt(), 0xFFA6FF4D.toInt(),
        0xFFFFFFFF.toInt(), 0xFF8FB8A3.toInt(), 0x6600C86A, true
    )
    val ALL = listOf(NORMAL, SPORT, SNOW, ECO)

    fun blend(a: Th, b: Th, t: Float): Th = Th(
        if (t < 0.5f) a.name else b.name,
        blendColors(a.bg, b.bg, t), blendColors(a.card, b.card, t),
        blendColors(a.c1, b.c1, t), blendColors(a.c2, b.c2, t), blendColors(a.c3, b.c3, t),
        blendColors(a.text, b.text, t), blendColors(a.sub, b.sub, t),
        blendAlpha(a.line, b.line, t),
        if (t < 0.5f) a.dark else b.dark
    )

    private fun blendAlpha(a: Int, b: Int, t: Float): Int {
        val al = ((a ushr 24) * (1 - t) + (b ushr 24) * t).toInt()
        return (al shl 24) or (blendColors(a, b, t) and 0x00FFFFFF)
    }
}
