Car Neon (v4) - داشبورد نئونی با مود رانندگی، دور موتور شبیه‌سازی‌شده CVT و نقشه

ساخت APK با GitHub: فایل zip را در یک repository آپلود کنید و فایل .github/workflows/build.yml
(همان فایل ساخت قبلی) را بسازید. بعد در تب Actions منتظر علامت سبز بمانید و CarNeon-APK را دانلود کنید.
